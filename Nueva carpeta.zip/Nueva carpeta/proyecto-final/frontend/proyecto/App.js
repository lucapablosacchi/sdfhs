import React from 'react';
import { Alert, StyleSheet, Text, View, TouchableWithoutFeedback,} from 'react-native';
import UselessTextInput from './UselessTextInput';

export default function App() {
  return (

    <View style={Styles.container}>

      <UselessTextInput></UselessTextInput>
      <Text style={Styles.container}>GLUME</Text>
       
    </View>

  )
}

const Styles = StyleSheet.create({

  container: {

    flex: 1,
    backgroundColor: '#EAFFDB',
    alignItems: 'center',
    justifyContent: 'center',
    position: "center",
    fontSize: 80,
    color: '#FA4677',
    fontWeight: 'bold',

  }
})
