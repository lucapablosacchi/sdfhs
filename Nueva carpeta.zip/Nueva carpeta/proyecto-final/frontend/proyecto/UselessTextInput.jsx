import React from "react";
import { SafeAreaView, StyleSheet, TextInput } from "react-native";

const UselessTextInput = () => {
  const [text, onChangeText] = React.useState(null);
  const [username, onChangeUsername] = React.useState(null);
  const [password, onChangePassword] = React.useState(null);


  return (
    <SafeAreaView>
      <TextInput
        style={styles.input}
        onChangeText={onChangeUsername}
        placeholder="Nombre de Usuario"
        value={username}
      />
      <TextInput
        style={styles.input}
        onChangeText={onChangePassword}
        value={password}
        placeholder="Contraseña"
        keyboardType="numeric"
      />
        <TextInput
        style={styles.input}
        onChangeText={onChangeText}
        placeholder="Tipo de Diabetes"
        value={text}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
    marginBottom: 1
},
});

export default UselessTextInput;