import config from "../dbconfig";
import sql from 'mssql';

class UsuarioService{

    getAll = async ()=>{
        try{
            const pool = await sql.connect(config);
            const result = await pool.request()
                .query("SELECT * FROM paciente");
            return result.recordset;
        }catch(error){
            console.log(error);
        }
    }

    getById = async (id) => {
        try{
            let pool = await sql.connect(config);
            let result = await pool.request()
                .input("id",sql.Int, id)
                .query('SELECT * FROM paciente WHERE id=@id');
            return result.recordset;
        } catch(error){
            console.log(error);
        }
    }
    // insert = async (usuario) => {
    //     try{
    //         let pool = await sql.connect(config);
    //         let result = await pool.request()
    //         .input("pNombre", sql.VarChar, usuario.nombre)
    //         .input("pApellido", sql.VarChar, usuario.apellido)
    //         .input("pNusuario", sql.VarChar, usuario.Nusuario)
    //         // ver contraseña
    //         .input("pContra", sql.VarChar, usuario.contra)
    //         .input("pMail", sql.VarChar, usuario.mail)
    //         .input("pDiabetesActual", sql.Float, usuario.diabetesActual)
    //         .input("pPeso", sql.Int, usuario.peso)
    //         .input("pAltura", sql.Float, usuario.altura)
    //         .input("pNacimiento", sql.Date, usuario.fechaNacimiento)
    //         .input("pContactoE", sql.Int, usuario.contactoE)
    //         .input("pTipoDiabetes", sql.Int, usuario.tipoDiabetes)
    //         .input("pRol", sql.Int, usuario.rol)
    //         .input("pSangre", sql.Int, usuario.sangre)
    //         .input("pOsocial", sql.Int, usuario.oSocial)
    //         .input("pMedico", sql.Int, usuario.medico)
    //         .query("INSERT INTO paciente (nombre,apellido,usuario,password,fechaNacimiento,mail,diabetesActual,peso,altura,fkContactoEmergencia,fkTipoDiabetes,fkRol,fkTipoSangre,fkObraSocial,fkMedico) 
    //         // VALUES (@pNombre,@pApellido,@pNusuario,@pDescripcion)")
    //     }catch(error){
    //         console.log(error);
    //     }
    // }
    deleteById = async (id) => {
        let rowsAffected=0;
        try{
            console.log(id)
            let pool = await sql.connect(config);
            let result = await pool.request()
                .input('pId',sql.Int, id)
                .query('DELETE FROM paciente WHERE Id = @pId');
            rowsAffected=result.rowsAffected;
            
        } catch(error){ 
            console.log(error);
        }
        return rowsAffected;

    }

    update = async (usuario) => {
        try{
            let pool = await sql.connect(config);
            let result = await pool.request()
            .input("pNombre", sql.VarChar, usuario.nombre)
            .input("pApellido", sql.VarChar, usuario.apellido)
            .input("pNusuario", sql.VarChar, usuario.Nusuario)
            // ver contraseña
            .input("pContra", sql.VarChar, usuario.contra)
            .input("pMail", sql.VarChar, usuario.mail)
            .input("pDiabetesActual", sql.Float, usuario.diabetesActual)
            .input("pPeso", sql.Int, usuario.peso)
            .input("pAltura", sql.Float, usuario.altura)
            .input("pNacimiento", sql.Date, usuario.fechaNacimiento)
            .input("pContactoE", sql.Int, usuario.contactoE)
            .input("pTipoDiabetes", sql.Int, usuario.tipoDiabetes)
            .input("pRol", sql.Int, usuario.rol)
            .input("pSangre", sql.Int, usuario.sangre)
            .input("pOsocial", sql.Int, usuario.oSocial)
            .input("pMedico", sql.Int, usuario.medico)
            .query("INSERT INTO paciente (nombre,libreGluten,importe,descripcion) VALUES (@pNombre,@pLibreGluten,@pImporte,@pDescripcion)")
        }catch(error){
            console.log(error);
        }
    }

}
export default UsuarioService;